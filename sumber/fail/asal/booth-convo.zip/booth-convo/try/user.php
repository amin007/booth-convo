<?php
//phpdanmysql.com - Membuat halaman kompirmasi pendaftar login
session_start();

include "koneksi.php";
if (isset($_SESSION['level']) && isset($_SESSION['username']))
{
   if ($_SESSION['level'] == "admin")
   {

if(isset($_POST['simpan'])){
$username=$_POST['username'];
$password=md5($_POST['password']);
$password2=md5($_POST['password2']);
$nama_lengkap=$_POST['nama_lengkap'];
$email=$_POST['email'];
$telp_hp=$_POST['telp_hp'];
$level=$_POST['level'];
$status=$_POST['status'];
if(empty($username)||empty($password)||empty($password2)||empty($nama_lengkap)||empty($email)||empty($telp_hp)||empty($level)||empty($status))
{
echo "<script type='text/javascript'>
	onload =function(){
	alert('Data belum lengkap, silahkan periksa kembali isian form!');
	}
	</script>";
}else{
$a="insert into user(username,password,nama_lengkap,email,telp_hp,level,status)values('$username','$password','$nama_lengkap','$email','$telp_hp','$level','$status')";
$b=mysql_query($a);
if($b){
echo "<script type='text/javascript'>
	onload =function(){
	alert('Data berhasil disimpan!');
	}
	</script>";
}else{
echo "<script type='text/javascript'>
	onload =function(){
	alert('Data gagal disimpan!');
	}
	</script>";
}
}
}

//Proses edit
//tampilkan data yang diedit
$username=$_GET['username'];
$sql="select * from user where username='$username'";
$query=mysql_query($sql);
$baris=mysql_fetch_array($query);

if(isset($_POST['Edit'])){
$password=md5($_POST['password']);
$nama_lengkap=$_POST['nama_lengkap'];
$email=$_POST['email'];
$telp_hp=$_POST['telp_hp'];
$level=$_POST['level'];
$status=$_POST['status'];
if(strlen($password)>0){
mysql_query("update user set password='$password' where username='$username'");
}

$a="Update user set nama_lengkap='$nama_lengkap',email='$email',telp_hp='$telp_hp',level='$level',status='$status' where username='$username'";
$b=mysql_query($a);
if($b){
header("location:user.php");
}else{
echo "<script type='text/javascript'>
	onload =function(){
	alert('User gagal diubah!');
	}
	</script>";
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Administrator Area - Kelola Kategori Berita</title>
</head>

<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#ffffff">
<table border="0" cellspacing="0" cellpadding="0" width="100%" height="83%">
  <tr>
	<td width="50%" background="../gambar/bg.gif"><img src="../gambar/px1.gif" width="1" height="1" alt="" border="0"></td>
	<td valign="bottom" background="../gambar/bg_left.gif"><img src="../gambar/bg_left.gif" alt="" width="17" height="16" border="0"></td>
	<td><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><?php include "header.php"; ?></td>
        </tr>
        <tr>
          <td background="../gambar/fon02.gif" height="34"><div align="center"></div></td>
        </tr>
      </table>
      <p align="center" class="px">
        <?php include "menu.php"; ?>
      <table width="644" border="0" align="center" cellpadding="1" cellspacing="0">
        <tr>
          <td width="549"><table width="598" border="0" align="center">
            <tr>
              <td width="518"><div align="center">
                <h2><strong>KELOLA USER 
                </strong></h2>
              </div>
                <form action="" method="post" name="form1" id="form1">
                    <table width="553" border="0" align="center" cellpadding="1" cellspacing="0">
                      <tr>
                        <td width="149">Username</td>
                        <td width="400"><label><?php if(!$_GET['username']){
                          echo "<input name='username' type='text' id='username' size='20'>";
						  }else{
						  echo "<b>".$baris['username']."</b>";
						  }
						  ?>
                        </label></td>
                      </tr>
                      <tr>
                        <td>Password</td>
                        <td><label>
                          <input name="password" type="password" id="password" size="25" />
                        </label>
						<?php
						if($_GET['username']){
						echo "<br><font color='red'>Apabila password tidak diubah, silahkan dikosongkan saja</font>";
						}
						?>						</td>
                      </tr>
						
                      <tr>
                        <td>Nama Lengkap </td>
                        <td><label>
                          <input name="nama_lengkap" type="text" id="nama_lengkap" size="35"  value="<?php echo $baris['nama_lengkap'];?>"/>
                        </label></td>
                      </tr>
                      <tr>
                        <td>Email</td>
                        <td><label>
                          <input name="email" type="text" id="email" size="35"  value="<?php echo $baris['email'];?>"/>
                        </label></td>
                      </tr>
                      <tr>
                        <td>Telpon/HP</td>
                        <td><label>
                          <input name="telp_hp" type="text" id="telp_hp" size="15"  value="<?php echo $baris['telp_hp'];?>"/>
                        </label></td>
                      </tr>
                      <tr>
                        <td>Level User </td>
                        <td><label>
                          <select name="level" id="level">
                            <option value="admin" <?php if($baris['level']=="admin"){ echo "selected";}?>>Administrator</option>
			    <option value="guru" <?php if($baris['level']=="guru"){ echo "selected";}?>>Guru</option>
                            <option value="user" <?php if($baris['level']=="user"){ echo "selected";}?>>User</option>
                          </select>
                        </label></td>
                      </tr>
                      <tr>
                        <td>Status User </td>
                        <td><p>
                          <label>
                            <input name="status" type="radio" value="Y"  <?php if($baris['status']=="Y"){ echo "checked";}?> />
                            Aktif</label>
                          <br />
                          <label>
                            <input type="radio" name="status" value="T" <?php if($baris['status']=="T"){ echo "checked";}?> />
                            Tidak Aktif</label>
                          <br />
                        </p></td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      <td><?php if(!$_GET['username']){
		//bila mau tambah data yang tampil tombol simpan
		echo "<input name=\"simpan\" type=\"submit\" id=\"simpan\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" type=\"reset\" id=\"batal\" value=\"Batal\" />";
        } else {
		//Apabila mau edit yg tampil tombol edit dan hapus
		echo "<input name=\"Edit\" type=\"submit\" id=\"edit\" value=\"Edit\" />";
		} ?>                      </tr>
                    </table>
                </form>
                <p align="center"> </p>
                <p align="center"> </p></td>
            </tr>
          </table>
          <h3 align="center">&nbsp;</h3>
            <h3 align="center">Tabel User  </h3>
            <table width="690" border="1" align="center" cellspacing="0">
              <tr bgcolor="#FFFF99">
                <td width="50"><div align="center"><strong>No</strong></div></td>
                <td width="100"><div align="center"><strong>Username</strong></div></td>
				<td width="150"><div align="center"><strong>Nama Lengkap</strong></div></td>
				<td width="150"><div align="center"><strong>Email</strong></div></td>
				<td width="100"><div align="center"><strong>Telephon/HP</strong></div></td>
				<td width="50"><div align="center"><strong>Level</strong></div></td>
				<td width="50"><div align="center"><strong>Status</strong></div></td>
                <td width="90"><div align="center"><strong>Aksi</strong></div></td>
              </tr>
			  <?php
			$hal = $_GET[hal];
			// jika page default nya 1
			if(!isset($_GET['hal'])){
			$halaman = 1;
			} else {
			$halaman = $_GET['hal'];
			}
			//tentukan jumlah data setiap halaman
			$hal_maksimum =10;
			// halaman di kali MAX jumlah item per halaman dikurangi MAX jumlah item per halaman
			$mulai = (($halaman * $hal_maksimum) - $hal_maksimum);
			  $sql="select * from user order by level ASC LIMIT $mulai, $hal_maksimum";
			  $query=mysql_query($sql);
			  $no=1;
			  while($data=mysql_fetch_array($query)){
			  ?>
              <tr>
                <td><div align="center"><?php echo $no; ?></div></td>
                <td><?php echo $data['username']; ?></td>
				<td><?php echo $data['nama_lengkap']; ?></td>
				<td><?php echo $data['email']; ?></td>
				<td><?php echo $data['telp_hp']; ?></td>
				<td><?php echo $data['level']; ?></td>
		<td><div align="center"><?php echo $data['status']; ?></td>
               <td><div align="center"><a href="user.php?username=<?php echo $data['username']; ?>"><img src="../gambar/button-edit.gif" width="20" height="20" /></a><a href="javascript:if(confirm('Anda yakin akan menghapus data ini??')){document.location='hapususer.php?username=<?php echo $data['username']; ?>';}"><img src="../gambar/button-cross.gif" width="20" height="20" /></a> </div></td>
              </tr>
             <?php 
			 $no++;
			 }?>
            </table>
<?php
$total= mysql_result(mysql_query("SELECT COUNT(*) as jumlah FROM user"),0);
$jumlah_halaman = ceil($total / $hal_maksimum);
// bangun jumlah hiperlink halaman
echo "<center>Halaman<br />";
// bangun Previous link
if($hal > 1){
$sebelum = ($halaman - 1);
echo "<a href=$_SERVER[PHP_SELF]?hal=$sebelum title=Sebelumnya>Prev</a>
";
}
for($i = 1; $i <= $jumlah_halaman; $i++){
if(($hal) == $i){
echo "$i ";
} else {
echo "<a href=$_SERVER[PHP_SELF]?hal=$i>$i</a> ";
}
}
// bangun Next link
if($hal < $jumlah_halaman){
$selanjutnya = ($halaman + 1);
echo "<a href=$_SERVER[PHP_SELF]?hal=$selanjutnya title=Selanjutnya>Next</a>";
}
echo "</center>";
?>       
            <p>&nbsp;</p>
          </td>
        </tr>
      </table>
	  <div class="px" align="center"><img src="../gambar/bot01.jpg" width="780" height="9" alt="" border="0"></div>
<table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
<tr>
	<td><p align="center">
	  <?php include "footer.php"; ?>
	</p></td>
	      <td height="50"> 
            <p class="bot">&nbsp;</p>
	</td>
</tr>
</table>
	</td>
	<td valign="bottom" background="../gambar/bg_right.gif"><img src="../gambar/bg_right.gif" alt="" width="17" height="16" border="0"></td>
	<td width="50%" background="../gambar/bg.gif"><img src="../gambar/px1.gif" width="1" height="1" alt="" border="0"></td>
</tr>
</table>

</body>
</html>
<?php
}
   else
   {
       // jika levelnya bukan admin, tampilkan pesan
       echo "<script>alert('Maaf.. Anda bukan admin');javascript:history.go(-1);</script>";
   }
}
else
{
   echo "<script>alert('Silakan login!!');javascript:history.go(-1);</script>";
}
?>