<html>
<head>
<title>Listing for Record Updating</title>
</head>
<body>
Listing for Record Updating<br> 
<?php 
//Check the record effected, if no records, 
//display a message if(mysqli_num_rows($qr)==0){ echo ("No record fetched...<br>"); }
//end no record else{
//there is/are record(s) 
?>
<table width="100%" border="1">
<tr align="center">
<td>Employee no.</td>
<td>First name</td>
<td>Last name</td>
<td>Department code</td>
<td>Phone no.</td>
</tr>
<?php while ($record=mysqli_fetch_array($qr)){ ?>
<tr>
<td><?=$record['EMPNO']?></td>
<td><?=$record['FIRSTNAME']?></td>
<td><?=$record['LASTNAME']?></td>
<td><?=$record['WORKDEPT']?></td>
<td><?=$record['PHONENO']?></td>
<td> <a href="formupdate.php?EMPNO=<?=$record['EMPNO']?>"> update </a>
</td>
</tr>
<?php
}//end of records
?>
</table>
<?php
//end if there are records
?>
</body>
</html>