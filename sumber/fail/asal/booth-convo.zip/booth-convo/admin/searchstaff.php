<?php
error_reporting(0);
session_start();
 
include('../config.php');

include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
											<!--Contents START-->
                          <form id="borang_pengesahan_pembayaran" name="borang_pengesahan_pembayaran" method="post" class="borang" style="padding-top:20px">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
									<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
										
										
										<tr>
										
											<td valign="top" bgcolor="#FFFFFF">
												<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
												<tr> 
												<td colspan="2"><br>
													
														<table width="750" border="0" cellspacing="1" cellpadding="3">
															</table>
													</div>
												</td>
											</tr>
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>Search staff to update/delete record</strong></div></td>
											</tr>
											<tr>
												
												<td><form class="form-inline" role="form" name="" action="" method="GET">
														<br><input class="input" name="staffname" type="text"  placeholder="admin name..." size="30"/>
														<input class="btn btn-embosed btn-primary" type="submit" value="Search">
														</div>
													</form>
												
												
										<br>
				<?php
		//capture textbox data
		if(isset($_GET['id'])){
			$key=$_GET['id'];
		}else{//tiada data dlm textbox
			echo "Please enter the staff name<br>";
			$key="No search key...";
		}
		//Create SQL query, add WHERE clause to narrow listing
		$query="select *
		from admin
		where id like '%$key%'";
		
		//Execute the query
		if($connect->connect_errno)
		{
			echo "Failed to connect to MySQL : ".$connect->error;
		}
		
		if ($connect->query($sql_daftar) == TRUE) 
			{
				echo "<script language=javascript>alert('Pendaftaran berjaya. Sila log masuk.');window.location='index.php';</script>";
			}
			else{//there is/are record(s)
			echo ("Found ".$connect->query($sql_daftar)." records by that name: $key...<br>");
			echo "
			<table width='100%' class='table table-hover table-bordered'>
				<thead>
					<th>EMPNO</th>
					<th>FIRSTNAME</th>
					<th>LASTNAME</th>
					<th>DEPARTMENT</th>
				</thead>";
			
			while ($result_daftar = $connect->query($sql_daftar)){
				$id=$result_daftar['id'];
				$urlupdate="updatestaff.php?id=".$id;
				$urldelete="deletestaff.php?id=".$id;
				echo "<tr>";
				echo "<td> $id
				<a href='$urlupdate' class='fui-new btn-warning' 
				title='Update staff $id info' 
				data-toggle='tooltip'></a>
				
				<a href='$urldelete' class='fui-trash btn-danger' 
				title='Delete staff $id info' 
				data-toggle='tooltip'></a>
				</td>";
				echo "<td>".$result_daftar['FIRSTNAME']."</td>";
				echo "<td>".$result_daftar['LASTNAME']."</td>";
				echo "<td>".$result_daftar['WORKDEPT']."</td>";
				echo "</tr>";
			}//end display records
			echo "</table>";
		}//end record found
		
		?>
													<!--Content ENDS-->
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
