</head>
<body>
<?php
error_reporting(0);
session_start();
// Menu ##############
   include('../config.php');
   
	$id=$row["id"];
	$nameadmin=$row["nameadmin"];
	$password=$row["password"];
	$email=$row["email"];
	$phoneno=$row["phoneno"];
	$address1=$row["address1"];
	$address2=$row["address2"];
	$city=$row["city"];
	$postcode=$row["postcode"];
	$state=$row["state"];

	
	  
$sql_admin = "UPDATE admin SET namadmin='$nameadmin', password='$password', email='$email', phoneno='$phoneno', address1='$address1', address2='$address2', city='$city', postcode='$postcode', state='$state',  WHERE id='$id' ";

if ($connect->query($sql_admin) == TRUE) {
    echo ("<script>alert('Update barn Successful.');
	document.location.href='searchstaff.php';</script>");
} else {
	echo ("<script>alert('Update goat Failed. Try Again.');
	document.location.href='searchstaff.php';</script>"). $connect->error;
}

?>