<?php
error_reporting(0);
session_start();
 
include('../config.php');

$id =$_GET['id'];
$sql_admin = "SELECT * FROM admin WHERE id = '$id'";

$count=1;
while($row = mysqli_fetch_array($sql_admin))
{
	

	$id=$row["id"];
	$nameadmin=$row["nameadmin"];
	$email=$row["email"];
	$phoneno=$row["phoneno"];
	$address1=$row["address1"];
	$address2=$row["address2"];
	$city=$row["city"];
	$postcode=$row["postcode"];
	$state=$row["state"];

}

?>

<?php
include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
											<!--Contents START-->
                         
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>List of admin</strong></div></td>
											</tr>
											<div class="row">
		<div class="col-sm-3">
			<br><br><br><br><br><br><br><br>
			<form method="POST" action="import.php" enctype="multipart/form-data">
				<div class="form-group">
					<label for="file">File:</label>
					<input type="file" id="file" name="file">
				</div>
				<button type="submit" name="import" class="btn btn-primary btn-sm">Import</button>
			</form>
			<?php
				session_start();
				if(isset($_SESSION['message'])){
					?>
					<div class="alert alert-info text-center" style="margin-top:20px;">
						<?php echo $_SESSION['message']; ?>
					</div>
					<?php

					unset($_SESSION['message']);
				}

			?>
		</div>
		<div class="col-sm-9">
			<br><table class="table table-bordered table-striped">
				<thead>
					<th>Employee No</th>
					<th>Admin Name</th>
					<th>Password</th>
					<th>Email</th>
				</thead>
				<tbody>
					<?php
					//connection
					$conn = new mysqli('localhost', 'root', '', 'booth');

					$sql = "SELECT * FROM admin";
					$query = $conn->query($sql);

					while($row = $query->fetch_array()){
						?>
						<tr>
							<td><?php echo $row['id']; ?></td>
							<td><?php echo $row['nameadmin']; ?></td>
							<td><?php echo $row['password']; ?></td>
							<td><?php echo $row['email']; ?></td>
						</tr>
						<?php
					}

					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
													<!--Content ENDS-->
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
