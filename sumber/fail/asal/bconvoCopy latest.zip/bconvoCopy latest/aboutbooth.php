<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include("header.php");
?>

		<div class="agileinfo-top-heading">
			<h2>ABOUT BOOTH</h2>
		</div>
	</div>
	<!-- //banner -->
	<!-- typography -->
	<center><br><p>Welcome to the unisza booth convocation, the launch will be carried out by the cansellor.</p>
	<p>This convocation booth provides vendors or students with business opportunities to venture into business.</p>
<br>
<p>The unisza booth convocation will provide 4 types of product categories for sale and has a total of 200 booths will be provided by Unisza.</p>
<br><br>
<p><b>MAIN INFORMATION</b></p>

<p>Performances by artist.</p>
<p>Various activities will be provided.</p>
<p>Cultural performances from multiple races.</p></center>
	<!-- //typography -->
	<!-- footer -->
	<?php
	include("footer.php");
	?>
	<!-- //footer -->
	<script src="js/SmoothScroll.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>	
</html>