<?php
// http://phpdanmysql.com
session_start();
include "koneksi.php";
//session login di php
if (isset($_SESSION['level']) && isset($_SESSION['username']) && isset($_SESSION['nama_lengkap']))
{
   if (($_SESSION['level'] == "admin")||($_SESSION['level'] == "guru")|($_SESSION['level'] == "user"))
   {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>http://phpdanmysql.com</title>
</head>

<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#ffffff">
<table border="0" cellspacing="0" cellpadding="0" width="100%" height="83%">
  <tr>
	<td width="50%" background="../gambar/bg.gif"><img src="../gambar/px1.gif" width="1" height="1" alt="" border="0"></td>
	<td valign="bottom" background="../gambar/bg_left.gif"><img src="../gambar/bg_left.gif" alt="" width="17" height="16" border="0"></td>
	<td bgcolor="#FFFFFF"><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#FFFFFF"><?php include "header.php"; ?></td>
        </tr>
        <tr>
          <td background="../gambar/fon02.gif" height="34"><div align="center"></div></td>
        </tr>
      </table>
      <p align="center" class="px">
        <?php include "menu.php"; ?>
      <table width="671" border="0" align="center" cellpadding="1" cellspacing="0">
        <tr>
          <td width="549" bgcolor="#FFFFFF"><h2 align="center">Selamat Datang <?php echo $_SESSION['nama_lengkap']; ?></h2>
            <p align="center">Silahkan gunakan menu di atas untuk mengatur sistem. Bila sudah selesai mengelola website, jangan lupa untuk mengklik LogOut.</p>
          <p align="center">Terima Kasih.</p>
          <p align="center">Developer</p>
          <p align="center"><strong>Abdul Adis S. Inf</strong></p>
		  <p align="center"><strong>PhpdanMySQL.Com</strong></p>
          <p align="center">&nbsp;</p></td>
	<p>&nbsp;</p>
        <p>&nbsp;</p>
        </tr>
      </table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
	  <div class="px" align="center"><img src="../gambar/bot01.jpg" width="780" height="9" alt="" border="0"></div>
<table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
<tr>
	<td><p align="center">
	  <?php include "footer.php"; ?>
	</p></td>
	<p>
	<td height="50"> 
        <p class="bot">&nbsp;</p>
	</td>
</tr>
</table>
	</td>
	<td valign="bottom" background="../gambar/bg_right.gif"><img src="../gambar/bg_right.gif" alt="" width="17" height="16" border="0"></td>
	<td width="50%" background="../gambar/bg.gif"><img src="../gambar/px1.gif" width="1" height="1" alt="" border="0"></td>
</tr>
</table>

</body>
</html>
<?php
}
   else
   {
       // jika levelnya bukan admin, tampilkan pesan
       echo "<script>alert('Maaf.. Anda Tidak Berhak Mengakses Halaman Ini!');javascript:history.go(-1);</script>";
   }
}
else
{
   echo "<script>alert('Silakan Login!!');javascript:history.go(-1);</script>";
}
?>