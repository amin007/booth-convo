<?php
error_reporting(0);
session_start();
 
include('../config.php');

include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
											<!--Contents START-->
                          <form id="borang_pengesahan_pembayaran" name="borang_pengesahan_pembayaran" method="post" class="borang" style="padding-top:20px">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
									<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
										
										
										<tr>
										
											<td valign="top" bgcolor="#FFFFFF">
												<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
												<tr> 
												<td colspan="2"><br>
													
														<table width="750" border="0" cellspacing="1" cellpadding="3">
															</table>
													</div>
												</td>
											</tr>
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>Search staff to update/delete record</strong></div></td>
											</tr>
											<tr>
												
												<td><form class="form-inline" role="form" name="" action="" method="GET">
														<br><input class="input" name="staffname" type="text"  placeholder="admin name..." size="30"/>
														<input class="btn btn-embosed btn-primary" type="submit" value="Search">
														</div>
													</form>
												
												
										<br>
				<?php
		//capture textbox data
		if(isset($_GET['nameadmin'])){
			$key=$_GET['nameadmin'];
		}else{//tiada data dlm textbox
			echo "Please enter the staff name<br>";
			$key="No search key...";
		}
		//Create SQL query, add WHERE clause to narrow listing
		$query="select id, nameadmin, password, email, phoneno, address1, address2, city, postcode, state 
		from admin
		where nameadmin like '%$key%'";
		
		//Execute the query
		if($connect->connect_errno)
		{
			echo "Failed to connect to MySQL : ".$connect->error;
		}
		
		if ($connect->query($sql_daftar) == 0) 
			{
					echo ("Sorry, seems that no record found by the keyword $nameadmin...<br>");
				}//end no record
				else
				{//there is/are record(s)
				?>{ //there is/are record(s)
			<h5>Search result "<?php echo $nameadmin; ?>"</h5><br>
					<table width="90%" class="table table-hover">
						<thead>
							<tr >
								<th>Employee no.</th>
								<th>Firstname</th>
								<th>Lastname</th>
								<th>Department</th>
								<th>Phone</th>
							</tr>
						</thead>
			<?php
			while ($result_daftar = $connect->query($sql_daftar)){
				?>
				<tr>
						<td>
						<?php
						$id=$result_daftar['nameadmin'];
						echo $id;
						$urlupdate="updatestaff.php?id=$id";
						$urldelete="delete.php?id=$id";
						?>
						<a href="<?php echo $urlupdate?>" class="btn btn-warning" title="Update staff record" 
						data-toggle="tooltip" > 
						<span class="fui-new"></span></a>
						<a href="#" class="btn btn-danger" title="Delete staff record!" 
						data-toggle="tooltip" onclick="alertdelete()"> 
						<script>
							//script to redirect delete page
							function alertdelete() {
								var r = confirm("You really want to delete the staff?");
								if (r == true) {
									window.location="<?php echo $urldelete?>";
								} else {
									
								}
							}
							</script>
						<span class="fui-trash"></span></a>
						
						</td>
						<td><?php echo $result_daftar['FIRSTNAME']?></td>
						<td><?php echo $result_daftar['LASTNAME']?></td>
						<td><?php echo $result_daftar['WORKDEPT']?></td>
						<td><?php echo $result_daftar['PHONENO']?></td>
					</tr>
				<?php
					}//end of records
				?>
				</table>
				<?php
				}//end if there are records
			//end db search
			?>
													<!--Content ENDS-->
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
