
<?php
session_start();
include('../config.php');
if(!isset($_SESSION['id']))
{
	echo "<script language=javascript>alert('Sila log masuk terlebih dahulu.');window.location='../login.php';</script>";
}

$sql = "SELECT * FROM vacancybooth WHERE id = '".$_SESSION['id']."'";
if($result = $connect->query($sql))
{
	$rows = $result->fetch_array();
	$total = $result->num_rows;
}

if(isset($_POST['save']))
{
	$id=$_POST["id"];
	$idvacancybooth=$_POST["idvacancybooth"];
	$categoryproduct=$_POST["categoryproduct"];
	$capacity=$_POST["capacity"];
	
	
$sql = "SELECT * FROM vacancybooth WHERE id = '".$_SESSION['id']."'";
	if($result = $connect->query($sql))
	{
		if($total = $result->num_rows)
		{
			
	 $sql = "UPDATE vacancybooth SET id = '".$id."', idvacancybooth = '".$idvacancybooth."', categoryproduct = '".$categoryproduct."', capacity = '".$capacity."'  WHERE id = '".$_SESSION['id']."'";
				if($result = $connect->query($sql))
				{
					echo "<script language=javascript>alert('Maklumat produk berjaya dikemaskini.');window.location='updateproduct.php';</script>";
				
					}
				else
				{
					echo "<script language=javascript>alert('Maklumat produk tidak berjaya dikemaskini. Sila cuba lagi.');window.location='updateproduct.php';</script>";
				
					}
			}
		}
	}

?>
<?php
include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            

                          <form id="borang_pengesahan_pembayaran" name="borang_pengesahan_pembayaran" method="post" class="borang" style="padding-top:20px">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											<tr>
												<td colspan="2" align="center"><div class="sub-tajuk-kelabu">UPDATE PRODUCT</div></td>
											</tr>
									
									<table border="2" cellspacing="2" align="center">
										
									<form action="" method="POST" align="center"><br>
		<input type="text" name="query" placeholder="search" />
		<input type="submit" name="cari" value="Search" />
	</form><br>
		<div class="col-sm-9">
			<br><table class="table table-bordered table-striped">
				<thead>
					<th>Id Admin</th>
					<th>Product No</th>
					<th>Category Product</th>
					<th>Capacity</th>
					<th>Action</th>
				</thead>
				<tbody>
					<?php
					//connection
					$conn = new mysqli('localhost', 'root', '', 'booth');

					$sql = "SELECT * FROM vacancybooth";
					$query = $conn->query($sql);

					while($row = $query->fetch_array()){
						?>
						<tr>
							<td><?php echo $row['id']; ?></td>
							<td><?php echo $row['idvacancybooth']; ?></td>
							<td><?php echo $row['categoryproduct']; ?></td>
							<td><?php echo $row['capacity']; ?></td>
							<td align="center"><button><a href="updateproduct.php? id=<?php echo $row['id'];?>">UPDATE</a></button> / <button><a class="button" onclick="return confirm_alert(this);" a href="deleteproduct.php? id=<?php echo $row['id'];?>">DELETE</a></button></td>    
		
						</tr>
	<?php
					}

					?>
	   </div>
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
