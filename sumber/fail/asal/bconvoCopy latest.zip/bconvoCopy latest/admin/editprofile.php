
<?php
session_start();
include('../config.php');

if(!isset($_SESSION['id']))
{
	echo "<script language=javascript>alert('Sila log masuk terlebih dahulu.');window.location='../login.php';</script>";
}

$sql = "SELECT * FROM admin WHERE id = '".$_SESSION['id']."'";
if($result = $connect->query($sql))
{
	$rows = $result->fetch_array();
	$total = $result->num_rows;
}

if(isset($_POST['save']))
{
				$id=$_POST["id"];
				$nameadmin=$_POST["nameadmin"];
				$password=$_POST["password"];
				$email=$_POST["email"];
				$phoneno=$_POST["phoneno"];
				$address1=$_POST["address1"];
				$address2=$_POST["address2"];
				$city=$_POST["city"];
				$postcode=$_POST["postcode"];
				$state=$_POST["state"];
				
		$sql = "SELECT * FROM admin WHERE id = '".$_SESSION['id']."'";
	if($result = $connect->query($sql))
	{
		if($total = $result->num_rows)
		{
			
		if($gambar!=NULL)
			{
				$sql = "UPDATE admin SET id = '".$id."', nameadmin = '".$nameadmin."', password = '".$password."', email = '".$email."', phoneno = '".$phoneno."', address1 = '".$address1."', address2 = '".$address2."', city = '".$city."', postcode = '".$postcode."', state = '".$state."', gambar = '".$gambar."' WHERE id = '".$_SESSION['id']."'";
				if($result = $connect->query($sql))
				{
					move_uploaded_file($_FILES['gambar']['tmp_name'], $target);
					echo "<script language=javascript>alert('Maklumat pelajar berjaya dikemaskini.');window.location='editprofile.php';</script>";
				
					}else
					{
						
					echo "<script language=javascript>alert('Maklumat pelajar berjaya dikemaskini.');window.location='editprofile.php';</script>";
				
					}
			}
			else
			{
				 $sql = "UPDATE admin SET id = '".$id."', nameadmin = '".$nameadmin."', password = '".$password."', email = '".$email."', phoneno = '".$phoneno."', address1 = '".$address1."', address2 = '".$address2."', city = '".$city."', postcode = '".$postcode."', state = '".$state."'  WHERE id = '".$_SESSION['id']."'";
				if($result = $connect->query($sql))
				{
					echo "<script language=javascript>alert('Maklumat pelajar berjaya dikemaskini.');window.location='editprofile.php';</script>";
				
					}
				else
				{
					echo "<script language=javascript>alert('Maklumat pelajar tidak berjaya dikemaskini. Sila cuba lagi.');window.location='editprofile.php';</script>";
				
					}
			}
		}
	}
}
?>
<?php
include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            

                          <form id="borang_pengesahan_pembayaran" name="borang_pengesahan_pembayaran" method="post" class="borang" style="padding-top:20px">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											<tr>
												<td colspan="2" align="center"><div class="sub-tajuk-kelabu">EDIT PROFILE</div></td>
											</tr>
										
									
									<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
										
										
										<tr>
										
											<td valign="top" bgcolor="#FFFFFF">
												<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
												<tr> 
												<td colspan="2"><br>
													
														<table width="750" border="0" cellspacing="1" cellpadding="3">
															
														</table>
													</div>
												</td>
											</tr>
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>INFORMATION DETAILS</strong></div></td>
											</tr>
											<tr>
												<td colspan="2" align="center"><br>
													<?php if($rows['gambar']==NULL) { ?>
													<img src="../images/no-image.gif" width="150" height="150" />
													<?php } else { ?>
													<img src="../images/admin/<?php echo $rows['gambar'];?>" width="150" height="150" />
													<?php } ?>
												</td>
											</tr>
											<tr>
												<td width="270" align="right">Gambar  :</td>
												<td width="480" align="left">
													<label for="gambar"></label>
													<input type="file" name="gambar" id="gambar" class="input" />
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Employee No  :</td>
												<td width="480" align="left">
													<span id="sprytextfield1">
														<br><?php echo $rows['id'];?><input type="hidden" name="id"  class="input" id="id" value="<?php echo $rows['id'];?>" size="45"/>
													</span>
												</td>
											</tr>
													<tr>
												<td width="270" align="right"><br>Full Name  :</td>
												<td width="480" align="left">
													<span id="sprytextfield2">
														<br><input name="nameadmin" type="text" class="input" id="nameadmin" value="<?php echo ucwords($rows['nameadmin']);?>" size="45"/>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Password  :</td>
												<td width="480" align="left">
													<span id="sprypassword1">
														<br><input name="password" type="password" class="input" id="password" value="<?php echo $rows['password'];?>" size="45" />
														<font color="#FF0000"><strong>*</strong></font><br/>
														<span class="passwordRequiredMsg">Password is required.</span>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Email  :</td>
												<td width="480" align="left">
													<span id="sprytextfield3">
														<br><input name="email" type="text" class="input" id="email" value="<?php echo $rows['email'];?>" size="45" />
													<font color="#FF0000"><strong>*</strong></font><br/>
														<span class="textfieldRequiredMsg">Email is required.</span>
														<span class="textfieldInvalidFormatMsg">Invalid Email.</span>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Phone Number  :</td>
												<td width="480" align="left">
													<span id="sprytextfield4">
														<br><input name="phoneno" type="text" class="input" id="phoneno" value="<?php echo $rows['phoneno'];?>" size="45" /><br/>
														<span class="textfieldInvalidFormatMsg">Invalid Phone Number.</span>
														<span class="textfieldMinCharsMsg">Invalid Phone Number.</span>
														<span class="textfieldMaxCharsMsg">Invalid Phone Number.</span>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Address1  :</td>
												<td width="480" align="left">
													<span id="sprytextfield5">
														<br><input name="address1" type="text" class="input" id="address1" value="<?php echo ucwords($rows['address1']);?>" size="45"/>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Address2  :</td>
												<td width="480" align="left">
													<span id="sprytextfield6">
														<br><input name="address2" type="text" class="input" id="address2" value="<?php echo ucwords($rows['address2']);?>"" size="45"/>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>City  :</td>
												<td width="480" align="left">
													<span id="sprytextfield7">
														<br><input name="city" type="text" class="input" id="city" value="<?php echo ucwords($rows['city']);?>" size="45"/>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Postcode  :</td>
												<td width="480" align="left">
													<br><input name="postcode" type="text" class="input" id="postcode" value="<?php echo $rows['postcode'];?>" size="45" placeholder="12345" /><br/>
														<span class="textfieldInvalidFormatMsg">Invalid Postcode.</span>
														<span class="textfieldMinCharsMsg">Invalid Postcode.</span>
														<span class="textfieldMaxCharsMsg">Invalid Postcode.</span>
													</span>
												</td>
											</tr>
													<tr>
												<td width="270" align="right"><br>State  :</td>
												<td width="480" align="left">
													<span id="spryselect1">
														<br><select name="state" id="state" class="input">
															<option value="" selected="selected">-- Choose State --</option>
															<option value="Johor" <?php if($rows['state']=="Johor") { ?>selected="selected"<?php } ?>>Johor</option>
															<option value="Melaka" <?php if($rows['state']=="Melaka") { ?>selected="selected"<?php } ?>>Melaka</option>
															<option value="Negeri Sembilan" <?php if($rows['state']=="Negeri Sembilan") { ?>selected="selected"<?php } ?>>Negeri Sembilan</option>
															<option value="Selangor" <?php if($rows['state']=="Selangor") { ?>selected="selected"<?php } ?>>Selangor</option>
															<option value="Putrajaya" <?php if($rows['state']=="Putrajaya") { ?>selected="selected"<?php } ?>>Putrajaya</option>
															<option value="Kuala Lumpur" <?php if($rows['state']=="Kuala Lumpur") { ?>selected="selected"<?php } ?>>Kuala Lumpur</option>
															<option value="Perak" <?php if($rows['state']=="Perak") { ?>selected="selected"<?php } ?>>Perak</option>
															<option value="Pulau Pinang" <?php if($rows['state']=="Pulau Pinang") { ?>selected="selected"<?php } ?>>Pulau Pinang</option>
															<option value="Kedah" <?php if($rows['state']=="Kedah") { ?>selected="selected"<?php } ?>>Kedah</option>
															<option value="Perlis" <?php if($rows['state']=="Perlis") { ?>selected="selected"<?php } ?>>Perlis</option>
															<option value="Kelantan" <?php if($rows['state']=="Kelantan") { ?>selected="selected"<?php } ?>>Kelantan</option>
															<option value="Terengganu" <?php if($rows['state']=="Terengganu") { ?>selected="selected"<?php } ?>>Terengganu</option>
															<option value="Pahang" <?php if($rows['state']=="Pahang") { ?>selected="selected"<?php } ?>>Pahang</option>
															<option value="Sabah" <?php if($rows['state']=="Sabah") { ?>selected="selected"<?php } ?>>Sabah</option>
															<option value="Sarawak" <?php if($rows['state']=="Sarawak") { ?>selected="selected"<?php } ?>>Sarawak</option>
															<option value="Lain-lain" <?php if($rows['state']=="Lain-lain") { ?>selected="selected"<?php } ?>>Lain-lain</option>
														</select>
													</span>
												</td>
											</tr>
													<tr>
												<td align="right">&nbsp;</td>
												<td align="left">
													<br><button type="submit" name="save" class="butangadmin"><span>SAVE</span></button>
													<button type="reset" class="butangadmin"><span>CLEAR</span></button>
												</td>
											</tr>
												</table>
											</td>
											
										</tr>
										<tr>
											
										</tr>
									</table>
								</form>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			
					</table>
				</td>
			</tr>
		</table>
		
	</div>
	<script type="text/javascript">
	var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["change"]});
	var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {isRequired:false})
	var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "email", {validateOn:["change"]});
	var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "integer", {validateOn:["change"], isRequired:false, minChars:10, maxChars:11});
	var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "none", {isRequired:false});
	var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6", "none", {isRequired:false});
	var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7", "none", {isRequired:false});
	var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1", {isRequired:false});
	var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8", "integer", {isRequired:false, minChars:5, maxChars:5, validateOn:["change"]});
	var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1", {validateOn:["change"]});

	</script>
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
