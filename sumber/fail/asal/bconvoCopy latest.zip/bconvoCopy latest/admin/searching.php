								
									<form id="borang_pengesahan_pembayaran" name="borang_pengesahan_pembayaran" method="post" class="borang" style="padding-top:20px">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
									<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
										
										
										<tr>
										
											<td valign="top" bgcolor="#FFFFFF">
												<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
												<tr> 
												<td colspan="2"><br>
													
														<table width="750" border="0" cellspacing="1" cellpadding="3">
															</table>
													</div>
												</td>
											</tr>
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>Search staff to update/delete record</strong></div></td>
											</tr>
											<tr>
												
												<td><form action="" method="POST" align="center"><br>
													<input type="text" name="query" placeholder="search" />
													<input type="submit" name="cari" value="Search" />
												</form><br>
	
	
	<table border="2" cellspacing="2" align="center">
		<tr style="font-weight:bold;">
			
			<td align="center">ID </td></center>
			<td align="center">NAME BARN</td></center>
			<td align="center">ACTION</td></center>
		</tr>
		<?php
		$no = 1;
		
		$query = $_POST['query'];
		if($query !=''){
			$sql_admin = "SELECT * FROM admin WHERE id LIKE '".$query."' OR nameadmin LIKE '".$query."'";
		}else{
			$sql_admin = "SELECT * FROM admin";
		}
		if(mysqli_num_rows($sql_admin)){
		while($row = mysqli_fetch_array($sql_admin)){
			
		?>
		
		<tr >
			<td align='center'><?php echo $row['id'] ?></td></center>
			<td align='center'><?php echo $row['nameadmin'] ?></td></center>
			
			
			<script>

//alert on delete

function confirm_alert(node) {

    return confirm("Are you sure to delete?. Click OK to delete a barn or CANCEL to quit.");

}

</script>
</head>
<body>
<form action="searching.php" method="POST">
<!--Put form elements here-->
			<td align="center"><button><a href="updatestaff.php? id=<?php echo $row['id'];?>">UPDATE</a></button> / <button><a class="button" onclick="return confirm_alert(this);" a href="deletestaff.php? id=<?php echo $baris['id'];?>">DELETE</a></button></td>    
		</tr>
		<?php }}else{

			echo '<tr><td colspan="9" align="center">No Data</td></tr>';
		}?>
		</div>

    </div>
  </div>
</div>