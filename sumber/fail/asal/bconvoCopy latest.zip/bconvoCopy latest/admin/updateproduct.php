
<?php
session_start();
include('../config.php');
if(!isset($_SESSION['id']))
{
	echo "<script language=javascript>alert('Sila log masuk terlebih dahulu.');window.location='../login.php';</script>";
}

$sql = "SELECT * FROM vacancybooth WHERE id = '".$_SESSION['id']."'";
if($result = $connect->query($sql))
{
	$rows = $result->fetch_array();
	$total = $result->num_rows;
}

if(isset($_POST['save']))
{
	$id=$_POST["id"];
	$idvacancybooth=$_POST["idvacancybooth"];
	$categoryproduct=$_POST["categoryproduct"];
	$capacity=$_POST["capacity"];
	
	
$sql = "SELECT * FROM vacancybooth WHERE id = '".$_SESSION['id']."'";
	if($result = $connect->query($sql))
	{
		if($total = $result->num_rows)
		{
			
	 $sql = "UPDATE vacancybooth SET id = '".$id."', idvacancybooth = '".$idvacancybooth."', categoryproduct = '".$categoryproduct."', capacity = '".$capacity."'  WHERE id = '".$_SESSION['id']."'";
				if($result = $connect->query($sql))
				{
					echo "<script language=javascript>alert('Maklumat produk berjaya dikemaskini.');window.location='updateproduct.php';</script>";
				
					}
				else
				{
					echo "<script language=javascript>alert('Maklumat produk tidak berjaya dikemaskini. Sila cuba lagi.');window.location='updateproduct.php';</script>";
				
					}
			}
		}
	}

?>
<?php
include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            

                          <form id="borang_pengesahan_pembayaran" name="borang_pengesahan_pembayaran" method="post" class="borang" style="padding-top:20px">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											<tr>
												<td colspan="2" align="center"><div class="sub-tajuk-kelabu">UPDATE PRODUCT</div></td>
											</tr>
										
									
									<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
										
										
										<tr>
										
											<td valign="top" bgcolor="#FFFFFF">
												<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
												<tr> 
												<td colspan="2"><br>
												
														<table width="750" border="0" cellspacing="1" cellpadding="3">
														
														</table>
													</div>
												</td>
											</tr>
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>PRODUCT INFORMATION DETAILS</strong></div></td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Id Admin  :</td>
												<td width="480" align="left">
													<span id="sprytextfield3">
														<br><?php echo ucwords($rows['id']);?><input name="id" type="hidden" class="input" id="id" value="<?php echo ucwords($rows['id']);?>" size="45"/>
													
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Product No  :</td>
												<td width="480" align="left">
													<span id="sprytextfield1">
														<br><input name="idvacancybooth" type="text" class="input" id="idvacancybooth" value="<?php echo ucwords($rows['idvacancybooth']);?>" size="45"/>
														<font color="#FF0000"><strong>*</strong></font><br/>
														<span class="textfieldRequiredMsg">Product No is required.</span>
													</span>
												</td>
											</tr>
													<tr>
												<td width="270" align="right"><br>Category Product  :</td>
												<td width="480" align="left">
													<span id="spryselect1">
														<br><select name="categoryproduct" id="categoryproduct" class="input">
															<option value="" selected="selected">-- Choose Product --</option>
															<option value="food" <?php if($rows['categoryproduct']=="food") { ?>selected="selected"<?php } ?>>Food</option>
															<option value="flower" <?php if($rows['categoryproduct']=="flower") { ?>selected="selected"<?php } ?>>Flower</option>
															<option value="clothes" <?php if($rows['categoryproduct']=="clothes") { ?>selected="selected"<?php } ?>>Clothes</option>
															<option value="cosmetic" <?php if($rows['categoryproduct']=="cosmetic") { ?>selected="selected"<?php } ?>>Cosmetic</option>
															
															</select>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Capacity  :</td>
												<td width="480" align="left">
													<span id="sprytextfield2">
														<br><input name="capacity" type="text" class="input" id="capacity" value="<?php echo ucwords($rows['capacity']);?>" size="45" placeholder="100"/>
														</span>
												</td>
											</tr>
											
											<tr>
												<td align="right">&nbsp;</td>
												<td align="left">
													<br><button type="submit" name="save" class="butangadmin"><span>SAVE</span></button>
													<button type="reset" class="butangadmin"><span>CLEAR</span></button>
												</td>
											</tr>
												</table>
											</td>
											
										</tr>
										<tr>
											
										</tr>
									</table>
								</form>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			
					</table>
				</td>
			</tr>
		</table>
		
	</div>
	<script type="text/javascript">
	var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["change"]});
	var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {validateOn:["change"]});
	var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "none", {validateOn:["change"]});
	var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1", {isRequired:false});
	</script>
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
