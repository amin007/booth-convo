<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include("header.php");
?>
		<div class="agileinfo-top-heading">
			<h2>RULES AND REGULATIONS</h2>
		</div>
	</div>
	<!-- //banner -->
	<!-- icons -->
	<br><center><p>Registeration fee process of RM50 is applicable for any category product.</p>
	<p>In the event of a cancellation or not eligible to participate for a whatever reason, the registeration fee process is non refundable.</p>
	<br><p><b>Terms Of Payment</b><p>
	<p>i. Booking registeration must be made together with full payment when the status is proceed with our organiser.</p>
	<p>ii. Full payment consists of the following:</p>
	<p>   a.Booth Rental</p>
	<p>   b.Refuncable Security Deposit</p>
	<p>ii. All registeration made with full payment are subject to final acceptance by the Organiser.<p>
	<p>iii. Payment shall be refunded in the event booking registeration is rejected.</p>
	<!-- //icons -->
	<!-- footer -->
	<?php
	include("footer.php");
	?>
	<!-- //footer -->
	<script src="js/SmoothScroll.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>	
</html>