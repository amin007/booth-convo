<footer>
		<div class="copyright">
			<div class="container">
				<p>© 2018 Booth Convocation Management System. All rights reserved | Design by Nur Iliya Liyana</a></p>
			</div>
		</div>
	</footer>