<?php
error_reporting(0);
session_start();
 
include('../config.php');

$id =$_GET['id'];
$sql_admin = "SELECT * FROM admin WHERE id = '$id'";

$count=1;
while($row = mysqli_fetch_array($sql_admin))
{
	

	$id=$row["id"];
	$nameadmin=$row["nameadmin"];
	$email=$row["email"];
	$phoneno=$row["phoneno"];
	$address1=$row["address1"];
	$address2=$row["address2"];
	$city=$row["city"];
	$postcode=$row["postcode"];
	$state=$row["state"];

}

?>

<?php
include("header.php");
?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
											<!--Contents START-->
                         <form name="update_staff1" enctype="multipart/form-data" method="POST" action="updatestaff1.php">
									<fieldset>
										<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
									<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
										
										
										<tr>
										
											<td valign="top" bgcolor="#FFFFFF">
												<table width="750" border="0" align="center" cellpadding="3" cellspacing="1">
											
												<tr> 
												<td colspan="2"><br>
													
														<table width="750" border="0" cellspacing="1" cellpadding="3">
															</table>
													</div>
												</td>
											</tr>
											<tr>
											
												<td colspan="2" align="center"><br><div class="sub-tajuk-kuning2"><strong>UPDATE EXISTING STAFF RECORD</strong></div></td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Employee No  :</td>
												<td width="480" align="left">
													<span id="sprytextfield1">
														<br><?php echo "$id" ?><input type="hidden" name="id" type="text" class="input" id="id" value="<?php echo "$id" ?> size="45"/>
														<font color="#FF0000"><strong>*</strong></font><br/>
														<span class="textfieldRequiredMsg">Employee no is required.</span>
													</span>
												</td>
											</tr>
													<tr>
												<td width="270" align="right"><br>Full Name  :</td>
												<td width="480" align="left">
													<span id="sprytextfield2">
														<br><?php echo "$nameadmin" ?><input name="nameadmin" type="text" class="input" id="nameadmin" value="<?php echo "$nameadmin" ?>" size="45"/>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Email  :</td>
												<td width="480" align="left">
													<span id="sprytextfield3">
														<br><?php echo "$email" ?><input name="email" type="text" class="input" id="email" value="<?php echo "$email"?>" size="45"/>
													<font color="#FF0000"><strong>*</strong></font><br/>
														<span class="textfieldRequiredMsg">Email is required.</span>
														<span class="textfieldInvalidFormatMsg">Invalid Email.</span>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Phone Number  :</td>
												<td width="480" align="left">
													<span id="sprytextfield4">
														<br><?php echo "$phoneno" ?><input name="phoneno" type="text" class="input" id="phoneno" value="<?php echo "$phoneno" ?>" size="45"/><br/>
														<span class="textfieldInvalidFormatMsg">Invalid Phone Number.</span>
														<span class="textfieldMinCharsMsg">Invalid Phone Number.</span>
														<span class="textfieldMaxCharsMsg">Invalid Phone Number.</span>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Address1  :</td>
												<td width="480" align="left">
													<span id="sprytextfield5">
														<br><?php echo "$address1" ?><input name="address1" type="text" class="input" id="address1" value="<?php echo "$address1" ?>" size="45"/>
													</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Address2  :</td>
												<td width="480" align="left">
													<span id="sprytextfield6">
														<br><?php echo "$address2" ?><input name="address2" type="text" class="input" id="address2" value="<?php echo "$address2" ?>" size="45"/>
														</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>City  :</td>
												<td width="480" align="left">
													<span id="sprytextfield7">
														<br><?php echo "$city" ?><input name="city" type="text" class="input" id="city" value="<?php echo "$city" ?>" size="45"/>
														</span>
												</td>
											</tr>
											<tr>
												<td width="270" align="right"><br>Postcode  :</td>
												<td width="480" align="left">
													<span id="sprytextfield8">
														<br><?php echo "$postcode" ?><input name="postcode" type="text" class="input" id="postcode" value="<?php echo "$postcode" ?>" size="45" /><br/>
														<span class="textfieldInvalidFormatMsg">Invalid Postcode.</span>
														<span class="textfieldMinCharsMsg">Invalid Postcode.</span>
														<span class="textfieldMaxCharsMsg">Invalid Postcode.</span>
													</span>
												</td>
											</tr>
													<tr>
												<td width="270" align="right"><br>State  :</td>
												<td width="480" align="left">
													<span id="spryselect1">
													
													
														<br><select name="state" id="state" class="input">
															<option value="<?php echo $state;?>" selected="selected"><?php echo $state;?></option>
															<option value="Johor">Johor</option>
															<option value="Melaka">Melaka</option>
															<option value="Negeri Sembilan">Negeri Sembilan</option>
															<option value="Selangor">Selangor</option>
															<option value="Putrajaya">Putrajaya</option>
															<option value="Kuala Lumpur">Kuala Lumpur</option>
															<option value="Perak">Perak</option>
															<option value="Pulau Pinang">Pulau Pinang</option>
															<option value="Kedah">Kedah</option>
															<option value="Perlis">Perlis</option>
															<option value="Kelantan">Kelantan</option>
															<option value="Terengganu">Terengganu</option>
															<option value="Pahang">Pahang</option>
															<option value="Sabah">Sabah</option>
															<option value="Sarawak">Sarawak</option>
															<option value="Lain-lain">Lain-lain</option>
														</select>
													</span>
												</td>
											</tr>
													<tr>
												<td align="right">&nbsp;</td>
												<td align="left">
													<br><button type="submit" name="save" class="butangadmin"><span>SIMPAN</span></button>
													<button type="reset" class="butangadmin"><span>PADAM</span></button>
												</td>
											</tr>
											
												</table>
											</td>
											
										</tr>
										<tr>
											
										</tr>
									</table>
								</form>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			
					</table>
				</td>
			</tr>
		</table>
		</div>
		<?php
		$count++;
		?>
	<script type="text/javascript">
	var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["change"]});
	var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {isRequired:false})
	var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "email", {validateOn:["change"]});
	var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "integer", {validateOn:["change"], isRequired:false, minChars:10, maxChars:11});
	var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "none", {isRequired:false});
	var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6", "none", {isRequired:false});
	var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7", "none", {isRequired:false});
	var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1", {isRequired:false});
	var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8", "integer", {isRequired:false, minChars:5, maxChars:5, validateOn:["change"]});
	
	
	</script>
													<!--Content ENDS-->
<script src="./vendor/jquery/jquery.min.js"></script>
<script src="./vendor/popper.js/popper.min.js"></script>
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="./vendor/chart.js/chart.min.js"></script>
<script src="./js/carbon.js"></script>
<script src="./js/demo.js"></script>
</body>
</html>
