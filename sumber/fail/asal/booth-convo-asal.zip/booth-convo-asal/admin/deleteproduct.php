<?php
include ("../config.php");

// sql to delete a record

$id = $_GET["id"];
$sql = "DELETE FROM vacancybooth WHERE id='$id'";

if ($connect->query($sql) === TRUE) {
   echo"<script>alert('Delete medicine success!!'); document.location.
   href='searchproduct.php'</script>";
} else {
    echo "Error deleting record: " . $connect->error;
}

$con->close() ;
?>