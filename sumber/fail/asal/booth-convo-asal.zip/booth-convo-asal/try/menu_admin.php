<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>http://phpdanmysql.com</title>
<style type="text/css">
<html>

#menu{
position:relative;
width:100%;
height:40px;
background:#FF0000;
background-color:#00FF00;
border:1px solid #000000;
}

#menu ul{
padding:0;
margin:0;
list-style:none;
}

#menu ul li{
float : left;
position:relative;
}

#menu ul li a{
float:left;
color:#000000;
padding:6px;
border-right:0px solid #ffcccc;
text-decoration:none;
display:block;
}

#menu ul li a:hover{
background-color:#CCFF00;
color:#990000;
}

#menu ul li ul {
display:none;
}

#menu ul li:hover ul{
display:block;
position:absolute;
top:30px;
left:0;
}

#menu ul li:hover ul li a{
display:block;
background:#99FF00;
color:#000000;
width:100px;
}

#menu ul li:hover ul li a:hover{
background:#FFCC33;
color:#003366;
}
</style>
</head>
<body>

  <div id="menu">
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="berita.php">Berita</a>
	<ul>
          <li><a href="kategori.php">Kategori Berita</a></li>
	</ul>
      </li>
      <li><a href="info_sekolah.php">Profil</a>
	<ul>
	<li><a href="kategori_info.php">Kategori Profil</a></li>
	</ul>	
	</li>
      <li><a href="guru.php">Guru</a></li>
      <li><a href="siswa.php">Siswa</a></li>
      <li><a href="galeri.php" >Galeri</a>
	<ul>
	<li><a href="/sma/adminpanel/admin/index.php">Tambah foto</a></li>
	</ul>	
	</li>
      <li><a href="buku_tamu.php">Tamu</a>
      <li><a href="user.php">User</a></li>
      <li><a href="absensi.php">Absensi</a></li>
      <li><a href="input_nilai.php">Nilai</a>
      <ul>
        <li><a href="mapel.php">Mapel</a></li>
      </ul>	
      </li>
      <li><a href="logout.php">logout</a></li>
      </ul>
  </div>
</div>
</body>
</html>