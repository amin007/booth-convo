<?php
// http://phpdanmysql.com - memulai session
session_start();
include "koneksi.php";
if(isset($_POST['login'])){
$username = $_POST['username'];
$password = md5($_POST['password']);
if(empty($username)){
echo "<script>alert('Username belum diisi!');javascript:history.go(-1);</script>";
}
elseif(empty($password)){
echo "<script>alert('Password belum diisi!');javascript:history.go(-1);</script>";
} else {
// query untuk mendapatkan record dari username
$query = "SELECT * FROM user WHERE username = '$username'";
$hasil = mysql_query($query);
$data = mysql_fetch_array($hasil);
 
// cek kesesuaian password
if ($password == $data['password'])
{
			echo "<script> document.location.href='adminpanel/home.php'; </script>";

    // menyimpan username dan level ke dalam session
    $_SESSION['level'] = $data['level'];
    $_SESSION['username'] = $data['username'];
	$_SESSION['nama_lengkap'] = $data['nama_lengkap'];
	$_SESSION['email'] = $data['email'];
	$_SESSION['status'] = $data['status'];
}
echo "<script>alert('Username atau password salah, ulangi kembali!');javascript:history.go(-1);</script>";
}
}
?>
<HTML>
<HEAD><TITLE>PhpdanMySQL.COM</TITLE>
</head>
<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#CCCCCC">
             <tr>
                  <h2 align="center">Login User </h2>
                <p align="center" class="style2"><img src="belajar php dan mysql1.png" width="300" height="80"></p>
                <table width="403" border="0" align="center" bgcolor="#CCFFCC">
                  <tr><p align="center" class="style9"><b>Silakan Login Untuk Masuk Ke Sistem</br> Jika Belum Memiliki Username dan Password </br>Silakan Daftar Terlebih Dahulu Dengan Cara Klik Daftar!</p>\
				  <td width="120"><form id="form1" name="form1" method="post" action="">
		<fieldset>
        <legend style="background-color:#FFCC33" align="center"><strong>Masukan Username & Password</strong></legend>
                           <table width="244" height="87" border="0" align="center">
                              <tr>
                                <td width="92"><strong>Username</strong></td>
                                <td width="210"><label>
                                  <input name="username" type="text" id="username" size="0" style="background:#FFFFFF" />
                                </label></td>
                              </tr>
                              <tr>
                                <td><strong>Password</strong></td>
                                <td><label>
                                  <input name="password" type="password" id="password" size="0" style="background:#FFFFFF" />
                                </label></td>
                              </tr>
						   <tr>
                           <td><strong>Level</strong></td>
                           <td><label> <br>
                           <select name="level">
						   <option value="admin">Admin</option>
						   <option value="guru">Guru</option>
						   <option value="user">User</option>
						   </select>
						   <br>
                           <br>
                           </label></td>
						   </tr>
						   <tr>
                                <td>&nbsp;</td>
                                <td><label>
                                  <input name="login" type="submit" id="login" style="background-color:#FFCC33" value="Login"/>
								  <a href="daftar_usr.php" class="font">Daftar!</a> 
								</label></td>
                                
                              </tr>
                        </table>
                    </form></td>
                  </tr>
                </table>
                <p align="center">
                <p align="center"> </p></td>
            </tr>
          </table></td>
          </tr>
      </table>
</body>
</html>