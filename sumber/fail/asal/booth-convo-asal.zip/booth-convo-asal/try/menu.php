<?php
// http://phpdanmysql.com
session_start();
 
if ($_SESSION['level'] == "admin"){
include "menu_admin.php";
}
else if ($_SESSION['level'] == "guru")
{
echo "
<table width='432' border='0' align='center' cellpadding='1' cellspacing='0'>
  <tr>
    <td><div align='center'><a href='home.php'><img src='../gambar/Home.png' width='48' height='48' border='0' /></a></div></td>
  <td><div align='center'><a href='input_nilai.php'><img src='../gambar/Notepad.png' width='48' height='48' border='0' /></a></div></td>
  <td><div align='center'><a href='laporan_absensi.php'><img src='../gambar/Books.png' width='48' height='48' border='0' /></a></div></td>
    <td><div align='center'><a href='logout_usr.php'><img src='../gambar/Minus.png' width='48' height='48' border='0' /></a></div></td>
  </tr>
  <tr>
    <td><div align='center'><span class='px style1'><a href='home.php' STYLE='TEXT-DECORATION:NONE'>Home</a></span></div></td>
    <td><div align='center'><a href='input_nilai.php' STYLE='TEXT-DECORATION:NONE'>Input Nilai</a></div></td>
    <td><div align='center'><a href='laporan_absensi.php' STYLE='TEXT-DECORATION:NONE'>Laporan Absensi</a></div></td>
    <td><div align='center'><a href='logout.php' STYLE='TEXT-DECORATION:NONE'>LogOut</a></div></td>
  </tr>
  </table>
<p>";
}
else if ($_SESSION['level'] == "user")
{
echo "
<table width='432' border='0' align='center' cellpadding='1' cellspacing='0'>
  <tr>
    <td><div align='center'><a href='home.php'><img src='../gambar/Home.png' width='48' height='48' border='0' /></a></div></td>
  <td><div align='center'><a href='nilai_siswa_user.php'><img src='../gambar/Notepad.png' width='48' height='48' border='0' /></a></div></td>
  <td><div align='center'><a href='laporan_absensi.php'><img src='../gambar/Books.png' width='48' height='48' border='0' /></a></div></td>
    <td><div align='center'><a href='logout.php'><img src='../gambar/Minus.png' width='48' height='48' border='0' /></a></div></td>
  </tr>
  <tr>
    <td><div align='center'><span class='px style1'><a href='home.php' STYLE='TEXT-DECORATION:NONE'>Home</a></span></div></td>
    <td><div align='center'><a href='nilai_siswa_user.php' STYLE='TEXT-DECORATION:NONE'>Laporan Nilai</a></div></td>
    <td><div align='center'><a href='laporan_absensi.php' STYLE='TEXT-DECORATION:NONE'>Laporan Absensi</a></div></td>
    <td><div align='center'><a href='logout.php' STYLE='TEXT-DECORATION:NONE'>LogOut</a></div></td>
  </tr>
  </table>
<p>";
}
?>