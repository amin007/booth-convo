<?php
//panggil koneksi - phpdanmysql.com
include "koneksi.php";
//ketika klik daftar - phpdanmysql.com
if(isset($_POST['daftar'])){
$username=$_POST['username'];
$password=md5($_POST['password']);
$password2=md5($_POST['password2']);
$nama_lengkap=$_POST['nama_lengkap'];
$email_usr=$_POST['email_usr'];
$telp_hp=$_POST['telp_hp'];
$level=$_POST['level'];
if(empty($username)||empty($password)||empty($password2)||empty($nama_lengkap)||empty($email_usr)||empty($telp_hp))
{
echo "<script type='text/javascript'>
	onload =function(){
	alert('Data belum lengkap, silahkan periksa kembali isian form!');
	}
	</script>";
}elseif($password != $password2)
{
echo "<script type='text/javascript'>
	onload =function(){
	alert('Password Pertama dan kedua tidak sama!');
	}
	</script>";
}else{
$a="insert into user(username,password,nama_lengkap,email,telp_hp,level,status)values('$username','$password','$nama_lengkap','$email_usr','$telp_hp','$level','Y')";
$b=mysql_query($a);
if($b){
//jika berhasil akan keluar pesan dibawah ini - phpdanmysql.com
echo "<script type='text/javascript'>
	onload =function(){
	alert('Pendaftaran Berhasil, Silahkan login untuk melihat Laporan Nilia Siswa dan Laporan Abensi..!');
	}
	</script>";
}else{
echo "<script type='text/javascript'>
	onload =function(){
	alert('Data gagal disimpan!');
	}
	</script>";
}
}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML>
<HEAD><TITLE>phpdanmysql.com</TITLE>
<META content=True name=MSSmartTagsPreventParsing>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
</head>
<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#ffffff">

  <tr>
	<td><table width="780" border="0" cellspacing="0" cellpadding="0">
      </table>
      
      <table width="600" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#0099FF">
        <tr>
          <td width="562" valign="top"><table width="508" border="0" align="center" bgcolor="#9999FF">
            <tr>
              <td width="518"><h2 align="center">&nbsp;</h2>
                  <h2 align="center" class="style2">Pendaftaran User </h2>
                <p align="center" class="style2"><img src="belajar php dan mysql1.PNG"></p>
                <form name="form1" method="post" action="">
                    <table width="349" border="0" align="center" cellpadding="1" cellspacing="0">
                      <tr>
                        <td width="103">Username</td>
                        <td width="210"><label>
                          <input name="username" type="text" id="username">
                        </label></td>
                      </tr>
                      <tr>
                        <td>Password</td>
                        <td><label>
                          <input name="password" type="password" id="password">
                        </label></td>
                      </tr>
                      <tr>
                        <td>Ulangi Password </td>
                        <td><label>
                          <input name="password2" type="password" id="password2">
                        </label></td>
                      </tr>
                      <tr>
                        <td colspan="2"><hr></td>
                      </tr>
                      <tr>
                        <td>Nama Lengkap </td>
                        <td><label>
                          <input name="nama_lengkap" type="text" id="nama_lengkap" size="35">
                        </label></td>
                      </tr>
                      <tr>
                        <td>Email</td>
                        <td><label>
                          <input name="email_usr" type="text" id="email" size="35">
                        </label></td>
                      </tr>
                      <tr>
                        <td>Telpon/HP</td>
                        <td><label>
                          <input name="telp_hp" type="text" id="telp_hp">
                        </label></td>
                      </tr>
					  <tr>
                           <td>Level</td>
                           <td><label>
						   <select name="level">
						   <option value="guru">Guru</option>
						   <option value="user">User</option>
						   </select>
						   </label></td>
						</tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td><label>
                          <input name="daftar" type="submit" id="daftar" value="Daftar">
                          <input type="reset" name="Submit2" value="Batal">
                          <a href="index.php">Login!!</a></label></td>
                      </tr>
					  <td>&nbsp;</td>
                    </table>
                </form>
                
            </tr>
          </table></td>
</body>
</html>